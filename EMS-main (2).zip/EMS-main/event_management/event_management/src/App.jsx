import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import NavBar from './components/NavBar';
import EventDashboard from './components/EventDashboard';
import Register from './components/Register';
import Login from './components/Login';
import TicketBooking from './components/TicketBooking';
import NotificationPanel from './components/NotificationPanel';
import FeedbackForm from './components/FeedbackForm';
import 'bootstrap/dist/css/bootstrap.min.css';
import './components/EventDashboard.css';

function App() {
  return (
<Router>
<NavBar />
<div className="container mt-3">
<Routes>
<Route path="/" element={<EventDashboard />} />
<Route path="/register" element={<Register />} />
<Route path="/login" element={<Login />} />
<Route path="/tickets" element={<TicketBooking />} />
<Route path="/notifications" element={<NotificationPanel />} />
<Route path="/feedback" element={<FeedbackForm />} />
</Routes>
</div>
</Router>
  );
}
 
export default App;