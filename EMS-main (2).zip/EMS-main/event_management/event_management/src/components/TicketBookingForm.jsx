import React from "react";
import { useParams } from "react-router-dom";
import { Container, Form, Button } from "react-bootstrap";

const TicketBookingForm = () => {
  const { eventId } = useParams();

  return (
    <Container className="mt-5">
      <h2>Book Ticket for Event {eventId}</h2>
      <Form>
        <Form.Group className="mb-3">
          <Form.Label>Name</Form.Label>
          <Form.Control type="text" placeholder="Enter name" />
        </Form.Group>

        <Form.Group className="mb-3">
          <Form.Label>Email</Form.Label>
          <Form.Control type="email" placeholder="Enter email" />
        </Form.Group>

        <Button variant="primary" type="submit">
          Confirm Booking
        </Button>
      </Form>
    </Container>
  );
};

export default TicketBookingForm;
