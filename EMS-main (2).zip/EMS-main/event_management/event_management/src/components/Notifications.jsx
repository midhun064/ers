import React from "react";
import { Container, ListGroup } from "react-bootstrap";

const notifications = [
  { id: 1, message: "Reminder: Music Concert tomorrow at 7 PM." },
  { id: 2, message: "Your ticket for Tech Conference has been confirmed!" },
];

const Notifications = () => {
  return (
    <Container className="mt-5">
      <h2>Notifications</h2>
      <ListGroup>
        {notifications.map((notification) => (
          <ListGroup.Item key={notification.id}>{notification.message}</ListGroup.Item>
        ))}
      </ListGroup>
    </Container>
  );
};

export default Notifications;
