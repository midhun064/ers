import React, { useEffect, useState } from 'react';
import { Container, Row, Col } from 'react-bootstrap';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';
import './EventDashboard.css';

const EventDashboard = () => {
  const [events, setEvents] = useState([]);
  const [search, setSearch] = useState('');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const navigate = useNavigate();

  useEffect(() => {
    fetchEvents();
  }, []);

  const fetchEvents = async () => {
    try {
      setLoading(true);
      const response = await axios.get('http://localhost:8082/events/getAllEvents');
      console.log('Fetched events:', response.data);
      setEvents(response.data);
    } catch (err) {
      setError(err.message);
      console.error('Error fetching events:', err);
    } finally {
      setLoading(false);
    }
  };

  const filteredEvents = events.filter(event =>
    event.name.toLowerCase().includes(search.toLowerCase()) ||
    event.category.toLowerCase().includes(search.toLowerCase()) ||
    event.location.toLowerCase().includes(search.toLowerCase())
  );

  const handleBookTicket = (eventId) => {
    navigate('/tickets', { state: { selectedEventId: eventId } });
  };

  return (
    <Container className="my-4">
      <h2 className="text-center mb-4">UPCOMING EVENTS</h2>
      <input
        type="text"
        placeholder="Search by name, category, location"
        value={search}
        onChange={e => setSearch(e.target.value)}
        className="form-control mb-4"
      />
      <Row>
        {filteredEvents.length > 0 ? (
          filteredEvents.map(event => (
            <Col key={event.eventId} md={3} className="mb-4">
              <div className="event-card">
                <div className="date-display">
                  <h1 className="day">{new Date(event.date).getDate()}</h1>
                  <div className="month">
                    {new Date(event.date).toLocaleString('default', { month: 'short' }).toUpperCase()}
                  </div>
                </div>
                <div className="event-details">
                  <h5 className="event-title">{event.name}</h5>
                  <p className="event-category">{event.category}</p>
                  <p className="event-location">@ {event.location}</p>
                  <p className="event-address">{event.address}</p>
                  <p className="ticket-count">Tickets: {event.ticketCount}</p>
                  <button
                    className="btn btn-primary book-ticket-btn"
                    onClick={() => handleBookTicket(event.eventId)}
                    disabled={event.ticketCount === 0}
                  >
                    {event.ticketCount > 0 ? 'Book Ticket' : 'Sold Out'}
                  </button>
                </div>
              </div>
            </Col>
          ))
        ) : (
          <Col>
            <p className="text-center">No events found.</p>
          </Col>
        )}
      </Row>
    </Container>
  );
};

export default EventDashboard;

