import React from "react";
import { useNavigate } from "react-router-dom";
import { Container, Button } from "react-bootstrap";

const LandingPage = () => {
  const navigate = useNavigate();

  const handleLogin = () => {
    navigate("/dashboard");
  };

  return (
    <Container className="text-center mt-5">
      <h1>Welcome to Event Management</h1>
      <Button variant="primary" className="m-2" onClick={handleLogin}>
        Login
      </Button>
      <Button variant="success" className="m-2" onClick={handleLogin}>
        Sign Up
      </Button>
    </Container>
  );
};

export default LandingPage;
