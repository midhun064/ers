import React, { useEffect, useState } from 'react';
import { useLocation } from 'react-router-dom';
import axios from 'axios';
 
const TicketBooking = () => {
  const location = useLocation();
  const selectedEventId = location.state?.selectedEventId;
  const [events, setEvents] = useState([]);
  const [tickets, setTickets] = useState([]);
  const [selectedEvent, setSelectedEvent] = useState(selectedEventId || '');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    fetchEvents();
    fetchUserTickets();
  }, []);

  const fetchEvents = async () => {
    try {
      const response = await axios.get('http://localhost:8082/events/getAllEvents');
      console.log('Fetched events:', response.data);
      
      // Filter and sort upcoming events
      const now = new Date();
      const upcomingEvents = response.data
        .filter(event => new Date(event.date) >= now)
        .sort((a, b) => new Date(a.date) - new Date(b.date));
      
      setEvents(upcomingEvents);
      
      // If there's a selectedEventId, verify it's still valid
      if (selectedEventId && upcomingEvents.some(e => e.eventId === selectedEventId)) {
        setSelectedEvent(selectedEventId);
      }
    } catch (err) {
      setError('Failed to load events: ' + err.message);
      console.error('Error fetching events:', err);
    } finally {
      setLoading(false);
    }
  };

  const fetchUserTickets = async () => {
    try {
      const response = await axios.get('http://localhost:8082/tickets/user');
      setTickets(response.data);
    } catch (err) {
      console.error('Error fetching tickets:', err);
    }
  };

  const handleBooking = async () => {
    if (!selectedEvent) {
      alert('Please select an event');
      return;
    }

    try {
      await axios.post('http://localhost:8082/tickets/book', {
        eventId: selectedEvent
      });
      alert('Ticket booked successfully!');
      fetchUserTickets(); // Refresh tickets list
      fetchEvents(); // Refresh event list to update ticket counts
    } catch (err) {
      alert('Booking failed: ' + err.message);
    }
  };

  if (loading) return <div className="text-center mt-5">Loading events...</div>;
  if (error) return <div className="text-center mt-5 text-danger">{error}</div>;

  return (
    <div className="container mt-4">
      <h2 className="mb-4">Ticket Booking</h2>
      <div className="card mb-4">
        <div className="card-body">
          <h5 className="card-title mb-3">Select Event</h5>
          <select 
            className="form-select mb-3" 
            value={selectedEvent} 
            onChange={e => setSelectedEvent(e.target.value)}
          >
            <option value="">Choose an event...</option>
            {events.map(event => {
              const eventDate = new Date(event.date);
              const formattedDate = eventDate.toLocaleDateString('en-US', {
                weekday: 'short',
                month: 'short',
                day: 'numeric'
              });
              const formattedTime = eventDate.toLocaleTimeString('en-US', {
                hour: '2-digit',
                minute: '2-digit'
              });
              
              return (
                <option 
                  key={event.eventId} 
                  value={event.eventId}
                  disabled={event.ticketCount === 0}
                >
                  {event.name} - {formattedDate} at {formattedTime} 
                  {event.ticketCount > 0 
                    ? ` (${event.ticketCount} tickets available)`
                    : ' (Sold Out)'}
                </option>
              );
            })}
          </select>

          {/* Show selected event details */}
          {selectedEvent && events.find(e => e.eventId === parseInt(selectedEvent)) && (
            <div className="alert alert-info mb-3">
              <h6>Selected Event Details:</h6>
              {(() => {
                const event = events.find(e => e.eventId === parseInt(selectedEvent));
                return (
                  <>
                    <p className="mb-1">Category: {event.category}</p>
                    <p className="mb-1">Location: {event.location}</p>
                    <p className="mb-0">Address: {event.address}</p>
                  </>
                );
              })()}
            </div>
          )}

          <button 
            className="btn btn-primary w-100"
            onClick={handleBooking}
            disabled={!selectedEvent || events.find(e => e.eventId === parseInt(selectedEvent))?.ticketCount === 0}
          >
            {!selectedEvent ? 'Select an Event' :
              events.find(e => e.eventId === parseInt(selectedEvent))?.ticketCount === 0 
                ? 'Sold Out' 
                : 'Book Ticket'}
          </button>
        </div>
      </div>

      <div className="card">
        <div className="card-body">
          <h5 className="card-title mb-3">Your Tickets</h5>
          {tickets.length > 0 ? (
            <div className="list-group">
              {tickets.map(ticket => (
                <div key={ticket.ticketId} className="list-group-item">
                  <div className="d-flex justify-content-between align-items-center">
                    <div>
                      <h6 className="mb-1">{ticket.eventName}</h6>
                      <small className="text-muted">
                        Booked on: {new Date(ticket.bookingDate).toLocaleDateString()}
                      </small>
                    </div>
                    <span className={`badge bg-${ticket.status === 'Confirmed' ? 'success' : 'secondary'}`}>
                      {ticket.status}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <p className="text-muted">No tickets booked yet.</p>
          )}
        </div>
      </div>
    </div>
  );
};

export default TicketBooking;