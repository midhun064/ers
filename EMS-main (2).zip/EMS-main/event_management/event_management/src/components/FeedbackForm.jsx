import React, { useEffect, useState } from 'react';
 
const FeedbackForm = () => {
  const [events, setEvents] = useState([]);
  const [selectedEvent, setSelectedEvent] = useState('');
  const [rating, setRating] = useState(0);
  const [comments, setComments] = useState('');
  const [averageRatings, setAverageRatings] = useState({});
 
  useEffect(() => {
    // Load all events for feedback
    fetch('/api/events')
      .then(res => res.json())
      .then(data => setEvents(data))
      .catch(err => console.error(err));
 
    // Load average ratings for events
    fetch('/api/feedback/averages')
      .then(res => res.json())
      .then(data => setAverageRatings(data))
      .catch(err => console.error(err));
  }, []);
 
  const handleSubmit = (e) => {
    e.preventDefault();
    if (!selectedEvent) return alert('Please select an event');
    if (rating === 0) return alert('Please provide a rating');
 
    fetch('/api/feedback/submit', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ eventID: selectedEvent, rating, comments }),
    })
      .then(res => {
        if (res.ok) {
          alert('Feedback submitted!');
          setRating(0);
          setComments('');
        } else {
          alert('Failed to submit feedback');
        }
      })
      .catch(err => alert('Error: ' + err.message));
  };
 
  return (
<div>
<h2>Feedback & Ratings</h2>
<form onSubmit={handleSubmit}>
<div className="mb-3">
<select className="form-select" value={selectedEvent} onChange={e => setSelectedEvent(e.target.value)} required>
<option value="">Select Event</option>
            {events.map(event => (
<option key={event.eventID} value={event.eventID}>
                {event.name}
</option>
            ))}
</select>
</div>
<div className="mb-3">
<label>Rating</label>
<select className="form-select" value={rating} onChange={e => setRating(Number(e.target.value))} required>
<option value={0}>Select rating</option>
            {[1, 2, 3, 4, 5].map(num => (
<option key={num} value={num}>{num} Star{num > 1 ? 's' : ''}</option>
            ))}
</select>
</div>
<div className="mb-3">
<label>Comments</label>
<textarea
            className="form-control"
            value={comments}
            onChange={e => setComments(e.target.value)}
            rows={3}
></textarea>
</div>
<button type="submit" className="btn btn-primary">Submit Feedback</button>
</form>
 
      <h3 className="mt-4">Average Ratings</h3>
      {events.length > 0 ? (
<ul className="list-group">
          {events.map(event => (
<li key={event.eventID} className="list-group-item d-flex justify-content-between align-items-center">
<span>{event.name}</span>
<span>{averageRatings[event.eventID] ? averageRatings[event.eventID].toFixed(1) : 'No ratings'} ⭐</span>
</li>
          ))}
</ul>
      ) : (
<p>No events available.</p>
      )}
</div>
  );
};
 
export default FeedbackForm;