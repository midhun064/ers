import React, { useState } from 'react';
 
const Login = () => {

  const [form, setForm] = useState({

    email: '',

    password: '',

  });
 
  const handleChange = e => {

    setForm({ ...form, [e.target.name]: e.target.value });

  };
 
  const handleSubmit = e => {

    e.preventDefault();

    // TODO: Call backend API for login and handle authentication token

    fetch('/api/users/login', {

      method: 'POST',

      headers: { 'Content-Type': 'application/json' },

      body: JSON.stringify(form),

    })

      .then(res => {

        if (res.ok) {

          return res.json();

        } else {

          throw new Error('Invalid credentials');

        }

      })

      .then(data => {

        // Save token or session here (e.g., localStorage)

        alert('Login successful!');

      })

      .catch(err => alert('Error: ' + err.message));

  };
 
  return (
<div>
<h2>User Login</h2>
<form onSubmit={handleSubmit}>
<div className="mb-3">
<label>Email</label>
<input

            name="email"

            type="email"

            className="form-control"

            value={form.email}

            onChange={handleChange}

            required

          />
</div>
<div className="mb-3">
<label>Password</label>
<input

            name="password"

            type="password"

            className="form-control"

            value={form.password}

            onChange={handleChange}

            required

          />
</div>
<button type="submit" className="btn btn-primary">Login</button>
</form>
</div>

  );

};
 
export default Login;

 