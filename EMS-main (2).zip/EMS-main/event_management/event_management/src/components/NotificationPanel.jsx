import React, { useEffect, useState } from 'react';
 
const NotificationPanel = () => {
  const [notifications, setNotifications] = useState([]);
 
  useEffect(() => {
    // Load notifications for the user
    fetch('/api/notifications/user')
      .then(res => res.json())
      .then(data => setNotifications(data))
      .catch(err => console.error(err));
  }, []);
 
  return (
<div>
<h2>Notifications</h2>
      {notifications.length > 0 ? (
<ul className="list-group">
          {notifications.map(note => (
<li key={note.notificationID} className="list-group-item">
<p>{note.message}</p>
<small>{new Date(note.sentTimestamp).toLocaleString()}</small>
</li>
          ))}
</ul>
      ) : (
<p>No notifications.</p>
      )}
</div>
  );
};
 
export default NotificationPanel;