import React, { useState } from 'react';
 
const Register = () => {
  const [form, setForm] = useState({
    name: '',
    email: '',
    password: '',
    contactNumber: '',
  });
 
  const handleChange = e => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };
 
  const handleSubmit = e => {
    e.preventDefault();
    // TODO: Call backend API to register user
    fetch('/api/users/register', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(form),
    })
      .then(res => {
        if (res.ok) alert('Registration successful!');
        else alert('Registration failed.');
      })
      .catch(err => alert('Error: ' + err.message));
  };
 
  return (
<div>
<h2>User Registration</h2>
<form onSubmit={handleSubmit}>
<div className="mb-3">
<label>Name</label>
<input name="name" type="text" className="form-control" value={form.name} onChange={handleChange} required />
</div>
<div className="mb-3">
<label>Email</label>
<input name="email" type="email" className="form-control" value={form.email} onChange={handleChange} required />
</div>
<div className="mb-3">
<label>Password</label>
<input name="password" type="password" className="form-control" value={form.password} onChange={handleChange} required />
</div>
<div className="mb-3">
<label>Contact Number</label>
<input name="contactNumber" type="text" className="form-control" value={form.contactNumber} onChange={handleChange} />
</div>
<button type="submit" className="btn btn-primary">Register</button>
</form>
</div>
  );
};
 
export default Register;