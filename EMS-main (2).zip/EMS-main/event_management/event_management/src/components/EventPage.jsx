import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { Container, Card, Button, Form } from "react-bootstrap";

const EventDashboard = () => {
  const [events, setEvents] = useState([]);
  const [search, setSearch] = useState("");
  const navigate = useNavigate();

  useEffect(() => {
    // Replace with actual backend API call
    fetch("/api/events")
      .then((res) => res.json())
      .then((data) => setEvents(data))
      .catch((err) => console.error("Error fetching events:", err));
  }, []);

  // Filtering logic for search functionality
  const filteredEvents = events.filter((event) =>
    event.name.toLowerCase().includes(search.toLowerCase()) ||
    (event.category && event.category.toLowerCase().includes(search.toLowerCase())) ||
    event.location.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <Container className="mt-5">
      <h2>Event Dashboard</h2>

      {/* Search Bar */}
      <Form.Control
        type="text"
        placeholder="Search events by name, category, or location"
        value={search}
        onChange={(e) => setSearch(e.target.value)}
        className="mb-3"
      />

      {/* Event Listing */}
      {filteredEvents.length > 0 ? (
        filteredEvents.map((event) => (
          <Card key={event.eventID} className="mb-3">
            <Card.Body>
              <Card.Title>{event.name}</Card.Title>
              <Card.Text>Category: {event.category}</Card.Text>
              <Card.Text>Location: {event.location}</Card.Text>
              <Card.Text>Date: {new Date(event.date).toLocaleDateString()}</Card.Text>
              <Button onClick={() => navigate(`/book-ticket/${event.eventID}`)}>
                Book Ticket
              </Button>
            </Card.Body>
          </Card>
        ))
      ) : (
        <p>No events found.</p>
      )}
    </Container>
  );
};

export default EventDashboard;
